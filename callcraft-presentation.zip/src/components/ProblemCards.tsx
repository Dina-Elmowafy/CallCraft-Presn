import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, EyeOff, Ban, Frown, Sparkles, CheckCircle2 } from 'lucide-react';

interface Problem {
  id: string;
  icon: any;
  title: string;
  desc: string;
  pain: string; // The painful legacy behavior
  solution: string; // How CallCraft automates it
}

export const ProblemCards: React.FC = () => {
  const [activeId, setActiveId] = useState<string | null>('1');

  const problems: Problem[] = [
    {
      id: '1',
      icon: AlertCircle,
      title: 'التقييم العشوائي البطيء',
      desc: 'الشركات تغطي أقل من 1-2% فقط من مكالماتها يدوياً بسبب غلاء تكلفة وقت مدراء الجودة والـ QA.',
      pain: 'مدير جودة يستمع عشوائياً لمكالمتين شهرياً لكل موظف ويغفل عن 98% من الأخطاء المتكررة.',
      solution: 'تحليل آلي فوري لـ 100% من المكالمات فور انتهائها وتوليد تقييم QA دقيق بدون أي تدخل بشري.'
    },
    {
      id: '2',
      icon: EyeOff,
      title: 'ضياع ثروة التفاصيل',
      desc: 'تفاصيل هامة واعتراضات العميل الحقيقية تضيع داخل التسجيلات المتراكمة دون توثيق حقيقي.',
      pain: 'الاعتماد على انطباعات الموظف الشخصية وكتابة ملاحظات مبهمة مثل "العميل يفكر بالعرّض".',
      solution: 'تفريغ نصي كامل، استخراج نية العميل، تصنيف مخاوفه ونقاط ألمه بدقة بالغة بالذكاء الاصطناعي.'
    },
    {
      id: '3',
      icon: Ban,
      title: 'خسارة الصفقات الغامضة',
      desc: 'الإدارة لا تعرف السبب الفعلي لانسحاب العميل، هل المشكلة من سوء العرض، أم التسعير، أم التسويق؟',
      pain: 'تبادل اللوم بين التسويق والمبيعات: المبيعات تشتكي جودة العملاء، والتسويق يتهم أداء الموظفين.',
      solution: 'تصنيف ذكي فوري للمشكلة: (Marketing Problem / Sales Problem) لوضع الإصبع على موضع الخلل بدقة.'
    },
    {
      id: '4',
      icon: Frown,
      title: 'سكريبت غير منضبط',
      desc: 'ضعف التزام الموظفين بالسكريبت البيعي، طريقة ترحيب باردة، أو إغفال التذكير بأكواد الخصم لتسريع الشراء.',
      pain: 'خسارة مبيعات مؤكدة بسبب نسيان الموظف الميزات التنافسية أو التعامل غير المهذب مع الاعتراض.',
      solution: 'مراقبة آلية لجميع قواعد الجودة والتحقق من التزام الموظف بالخطوات مع تقديم نصائح تدريبية مخصصة للحال.'
    }
  ];

  return (
    <div className="flex flex-col lg:flex-row gap-8 w-full max-w-6xl items-stretch">
      {/* Selector Side */}
      <div className="lg:w-1/2 flex flex-col gap-3 justify-center">
        {problems.map((prob) => {
          const Icon = prob.icon;
          const isActive = activeId === prob.id;
          return (
            <button
              key={prob.id}
              onClick={() => setActiveId(prob.id)}
              className={`p-5 rounded-2xl border text-right transition-all duration-300 flex items-center gap-5 w-full ${
                isActive 
                  ? 'bg-white/10 border-[#C5A059] shadow-xl text-[#F9F8F4]' 
                  : 'bg-white/5 border-white/10 text-white/70 hover:border-white/20 hover:bg-white/10'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                isActive ? 'bg-[#C5A059] text-black font-bold' : 'bg-white/5 text-white/50'
              }`}>
                <Icon size={20} />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-base leading-tight mb-1">{prob.title}</h4>
                <p className={`text-xs ${isActive ? 'text-[#C5A059]' : 'text-white/40'} line-clamp-1`}>{prob.desc}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Comparison Detail Side */}
      <div className="lg:w-1/2 flex items-center">
        <AnimatePresence mode="wait">
          {problems.map((prob) => {
            if (prob.id !== activeId) return null;
            return (
              <motion.div
                key={prob.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="w-full bg-white/5 p-8 md:p-10 rounded-3xl border border-white/10 backdrop-blur-sm flex flex-col justify-between"
              >
                <div>
                  <h3 className="text-2xl font-serif font-black text-white mb-4">{prob.title}</h3>
                  <p className="text-white/60 text-sm leading-relaxed mb-8">{prob.desc}</p>
                  
                  <div className="space-y-6">
                    {/* Pain Legacy */}
                    <div className="p-5 bg-white/5 rounded-2xl border border-white/10">
                      <div className="flex items-center gap-3 mb-2 text-white/80 font-bold text-xs uppercase tracking-wider">
                        <AlertCircle size={16} className="text-[#C5A059]" />
                        <span>ما يحدث تقليدياً (المظهر المؤلم)</span>
                      </div>
                      <p className="text-white/50 text-xs leading-relaxed font-medium">{prob.pain}</p>
                    </div>

                    {/* Solution CallCraft */}
                    <div className="p-5 bg-[#C5A059] text-black rounded-2xl transform hover:scale-[1.01] transition-transform">
                      <div className="flex items-center gap-3 mb-2 text-black/80 font-black text-xs uppercase tracking-wider">
                        <Sparkles size={16} className="animate-spin [animation-duration:15s]" />
                        <span>كيف يحلها CALLCRAFT الذكي؟</span>
                      </div>
                      <p className="text-black text-xs leading-relaxed font-bold">{prob.solution}</p>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-4 border-t border-white/10 flex items-center justify-between text-[10px] font-bold text-white/45 tracking-wider">
                  <span>تم الفهم والتشخيص</span>
                  <div className="flex items-center gap-2 text-[#C5A059]">
                    <CheckCircle2 size={14} />
                    <span>جاهز للأتمتة</span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, FileText, Check, AlertCircle, Sparkles, RefreshCw, Star, Heart, TrendingUp, Sliders, Play, Pause, ChevronLeft } from 'lucide-react';
import { PresetCall } from '../types';
import { presetCalls } from '../data/presetCalls';

export const LiveSandboxDemo: React.FC = () => {
  const [selectedPresetId, setSelectedPresetId] = useState<string>('1');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisProgress, setAnalysisProgress] = useState<number>(0);
  const [activeCallReport, setActiveCallReport] = useState<PresetCall | null>(null);
  const [dragOver, setDragOver] = useState<boolean>(false);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [playingSegment, setPlayingSegment] = useState<number | null>(null);

  // Trigger analysis simulation
  const startAnalysis = (call: PresetCall) => {
    setIsAnalyzing(true);
    setAnalysisProgress(0);
    setActiveCallReport(null);

    const interval = setInterval(() => {
      setAnalysisProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setIsAnalyzing(false);
            setActiveCallReport(call);
          }, 300);
          return 100;
        }
        return prev + 10;
      });
    }, 150);
  };

  // Run initial call report on mount
  useEffect(() => {
    const defaultCall = presetCalls.find(c => c.id === selectedPresetId);
    if (defaultCall) {
      setActiveCallReport(defaultCall);
    }
  }, []);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = () => {
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelection(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelection(files[0]);
    }
  };

  const handleFileSelection = (file: File) => {
    setUploadedFileName(file.name);
    // Dynamically generate a custom call report for the uploaded file!
    const customCall: PresetCall = {
      id: 'custom',
      title: `ملف مرفوع: ${file.name}`,
      description: 'تحليل مخصص للملف الصوتي المرفوع من قبلك',
      audioDuration: '2:30',
      agentName: 'الوكيل السحابي',
      type: 'sale',
      qaScore: 88,
      sentiment: 'positive',
      classifiedAs: 'No Clear Problem',
      strengths: [
        'الالتزام بالترحيب والتحية الافتتاحية طبقاً لسياسة المتجر في الثانية 04.',
        'نبرة هادئة ومتعاطفة ساعدت في توثيق العلاقة مع العميل.',
        'فهم الاحتياج الأساسي وتقدير المخاوف المتعلقة بالشحن والمواعيد.'
      ],
      weaknesses: [
        'لم يتم التذكير بأكواد الخصم لتسريع إتمام صفقة البيع.'
      ],
      recommendation: 'أداء العام جيد وواعد جداً. يوصى فقط بحث الوكيل على الالتزام بالتذكير بأكواد الخصم والبدائل السريعة لزيادة دقة الإغلاق الكلي للمكالمات البيعية.',
      transcript: [
        { speaker: 'Agent', time: '00:03', text: 'أهلاً بك ممتنون لاتصالك، معك الدعم الذكي كيف يمكنني مساعدتك؟' },
        { speaker: 'Customer', time: '00:15', text: 'أهلاً، واجهتني مشكلة أثناء تفعيل باقة مبيعات SaaS وأريد حلاً لمشكلة الربط.' },
        { speaker: 'Agent', time: '00:32', text: 'أتفهمك تماماً. سأقوم بإرسال كود التفعيل الذكي فوراً ونبدأ دمج النظام مع خدماتكم اليوم.' }
      ]
    };
    startAnalysis(customCall);
  };

  return (
    <div className="w-full max-w-6xl flex flex-col gap-6 text-right" dir="rtl">
      
      {/* Upper Control Grid (Preset selection & File uploader) */}
      {!isAnalyzing && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch shrink-0">
          
          {/* Preset Buttons */}
          <div className="lg:col-span-7 bg-white/5 p-6 rounded-3xl border border-white/10 flex flex-col justify-between backdrop-blur-sm">
            <div>
              <h4 className="font-serif text-white text-base font-bold mb-4 flex items-center gap-2">
                <Sliders size={18} className="text-[#C5A059]" />
                <span>اختر مكالمة مسجلة مسبقاً وتفحص تحليلها</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {presetCalls.map((call) => {
                  const isSelected = selectedPresetId === call.id && !uploadedFileName;
                  return (
                    <button
                      key={call.id}
                      onClick={() => {
                        setUploadedFileName(null);
                        setSelectedPresetId(call.id);
                        startAnalysis(call);
                      }}
                      className={`p-4 rounded-2xl border text-right transition-all duration-300 flex flex-col justify-between h-28 cursor-pointer ${
                        isSelected 
                          ? 'bg-white/10 border-[#C5A059] text-white shadow-lg shadow-[#C5A059]/5' 
                          : 'bg-white/5 border-white/10 text-white/70 hover:border-white/20 hover:bg-white/10'
                      }`}
                    >
                      <span className="text-[10px] font-bold tracking-tight block truncate mb-1">{call.title}</span>
                      <span className={`text-[8px] uppercase tracking-wider font-semibold block mb-2 ${
                        isSelected ? 'text-[#C5A059]' : 'text-white/40'
                      }`}>
                        الموظف: {call.agentName} | المدة: {call.audioDuration}
                      </span>
                      <span className="text-[9px] font-bold text-[#C5A059] flex items-center gap-1 mt-auto">
                        <span>ابدأ التحليل</span>
                        <ChevronLeft size={10} />
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Interactive Drag and Drop File Uploader */}
          <div className="lg:col-span-5">
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`h-full p-6 rounded-3xl border-2 border-dashed transition-all duration-300 flex flex-col items-center justify-center text-center cursor-pointer relative ${
                dragOver 
                  ? 'border-[#C5A059] bg-[#C5A059]/10' 
                  : 'border-white/20 bg-white/5 hover:border-[#C5A059]/40 hover:bg-white/10'
              }`}
            >
              <input 
                type="file" 
                id="file-upload" 
                accept="audio/*" 
                onChange={handleFileInput}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
              <Upload size={36} className={`${dragOver ? 'text-[#C5A059] animate-bounce' : 'text-white/40'} mb-3`} />
              <h5 className="font-bold text-white text-xs mb-1">اسحب ملف مكالمة صوتية أو انقر هنا</h5>
              <p className="text-[9px] text-white/45 max-w-xs leading-normal">
                ندعم جميع صيغ الصوت: MP3, WAV, M4A, OGG وغيرها. النظام يتعرف فوراً على الموظف ويبدأ التحليل.
              </p>
              {uploadedFileName && (
                <div className="mt-3 px-3 py-1 bg-[#C5A059]/20 border border-[#C5A059]/40 rounded-lg text-[10px] text-[#DBBE83] font-bold block">
                  {uploadedFileName}
                </div>
              )}
            </div>
          </div>

        </div>
      )}

      {/* Analyzing Progress Loader Screen */}
      <AnimatePresence mode="wait">
        {isAnalyzing && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="w-full bg-white/5 border border-white/10 text-white rounded-3xl p-16 flex flex-col items-center justify-center text-center shadow-xl min-h-[45vh] backdrop-blur-sm"
          >
            <RefreshCw size={48} className="text-[#C5A059] animate-spin mb-6" />
            <h3 className="font-serif text-3xl font-black mb-2">جاري استجماع وفك تشفير المكالمة...</h3>
            <p className="text-white/40 text-[10px] tracking-wider uppercase mb-8 font-mono">
              FastAPI AI Engine is analyzing audio vectors & hash matching
            </p>
            <div className="w-full max-w-md h-1.5 bg-white/10 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-[#C5A059] shadow-[0_0_15px_#C5A059]"
                animate={{ width: `${analysisProgress}%` }}
                transition={{ ease: "easeOut" }}
              />
            </div>
            <span className="text-xs font-mono font-bold text-[#C5A059] mt-3">{analysisProgress}%</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Complete Dissected Report View */}
      {!isAnalyzing && activeCallReport && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 border border-white/10 rounded-3xl shadow-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch backdrop-blur-sm"
        >
          {/* Detailed Transcript & QA parameters (Left Side) */}
          <div className="lg:col-span-8 p-6 md:p-10 flex flex-col justify-between border-l border-white/10 bg-black/20">
            <div>
              {/* Header Title */}
              <div className="flex justify-between items-start pb-6 border-b border-white/10 mb-6">
                <div>
                  <h3 className="text-2xl font-serif font-black text-white mb-1">{activeCallReport.title}</h3>
                  <p className="text-xs text-white/40">{activeCallReport.description}</p>
                </div>
                <span className={`px-4 py-1.5 rounded-full text-xs font-bold ${
                  activeCallReport.classifiedAs === 'No Clear Problem' 
                    ? 'bg-[#C5A059]/20 text-[#DBBE83] border border-[#C5A059]/30'
                    : activeCallReport.classifiedAs === 'Sales Problem'
                      ? 'bg-amber-950/40 text-amber-300 border border-amber-900/40'
                      : 'bg-red-950/40 text-red-300 border border-red-900/40'
                }`}>
                  تصنيف المشكلة الكلي: {activeCallReport.classifiedAs === 'No Clear Problem' ? 'مكالمة ناجحة ومثالية' : activeCallReport.classifiedAs}
                </span>
              </div>

              {/* Chat Transcript Area */}
              <div className="space-y-4 max-h-[30vh] overflow-y-auto pr-3 mb-8">
                <h4 className="font-serif text-white/80 text-sm font-bold mb-2">التفريغ النصي الذكي والمنسق:</h4>
                {activeCallReport.transcript.map((lines, i) => {
                  const isAgent = lines.speaker === 'Agent';
                  const isPlayingThis = playingSegment === i;
                  return (
                    <div 
                      key={i} 
                      onClick={() => setPlayingSegment(isPlayingThis ? null : i)}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                        isPlayingThis 
                          ? 'bg-[#C5A059]/10 border-[#C5A059]/30 shadow-sm' 
                          : 'bg-white/5 border-transparent hover:border-white/10 hover:bg-white/10'
                      } flex flex-col gap-1.5`}
                    >
                      <div className="flex justify-between items-center text-[10px] font-bold">
                        <span className={`px-2 py-0.5 rounded ${
                          isAgent ? 'bg-[#C5A059]/20 text-[#DBBE83]' : 'bg-white/15 text-white/80 border border-white/10'
                        }`}>
                          {isAgent ? `الوكيل ${activeCallReport.agentName}` : 'العميل المستفسر'}
                        </span>
                        <div className="flex items-center gap-2">
                          {isPlayingThis ? <Pause size={10} className="text-[#C5A059] animate-pulse" /> : <Play size={10} className="text-white/40" />}
                          <span className="font-mono text-white/45">{lines.time}</span>
                        </div>
                      </div>
                      <p className="text-xs text-white/80 leading-relaxed font-sans">{lines.text}</p>
                    </div>
                  );
                })}
              </div>

              {/* Strengths & Weaknesses block */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-white/10">
                {/* Strengths */}
                <div className="space-y-3">
                  <h5 className="text-xs font-bold text-emerald-400 flex items-center gap-2">
                    <Check size={16} className="text-emerald-400" />
                    <span>نقاط قوة موظفك بالمكالمة:</span>
                  </h5>
                  <div className="space-y-1.5">
                    {activeCallReport.strengths.map((str, sIdx) => (
                      <div key={sIdx} className="text-[11px] text-white/60 leading-normal flex gap-2">
                        <span className="text-[#C5A059] shrink-0">•</span>
                        <span>{str}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Weaknesses */}
                <div className="space-y-3">
                  <h5 className="text-xs font-bold text-[#C5A059] flex items-center gap-2">
                    <AlertCircle size={16} className="text-[#C5A059]" />
                    <span>نقاط الضعف الفورية بالمكالمة:</span>
                  </h5>
                  <div className="space-y-1.5">
                    {activeCallReport.weaknesses.map((weak, wIdx) => (
                      <div key={wIdx} className="text-[11px] text-white/60 leading-normal flex gap-2">
                        <span className="text-[#C5A059] shrink-0">•</span>
                        <span>{weak}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="text-[9px] font-mono text-white/40 mt-6 select-none uppercase tracking-widest text-left">
              CallCraft Dissected Intelligence Report
            </div>
          </div>

          {/* AI Trainer Coach Recommendations (Right Side) */}
          <div className="lg:col-span-4 bg-white/5 text-white p-8 md:p-10 flex flex-col justify-between border-t lg:border-t-0 lg:border-r border-white/10 font-sans">
            <div className="space-y-6">
              
              {/* QA Rating badge */}
              <div className="text-center p-6 bg-white/5 rounded-3xl border border-white/10">
                <span className="text-[10px] font-black uppercase text-white/40 tracking-widest block mb-2">الدرجة النهائية الكلية</span>
                <div className="text-6xl font-serif font-black text-[#C5A059] mb-2">{activeCallReport.qaScore}%</div>
                <div className="flex justify-center text-[#C5A059] gap-0.5">
                  {Array.from({ length: 5 }).map((_, starIdx) => {
                    const stars = Math.round(activeCallReport.qaScore / 20);
                    return <Star key={starIdx} size={14} fill={starIdx < stars ? "currentColor" : "none"} className={starIdx < stars ? "text-[#C5A059]" : "text-white/10"} />;
                  })}
                </div>
              </div>

              {/* Sentiment Block */}
              <div className="space-y-2 font-black">
                <span className="text-[10px] font-black uppercase text-white/40 tracking-widest block">نبرة مشاعر العميل الكلية:</span>
                <div className="flex items-center gap-3 bg-white/5 px-4 py-3 rounded-2xl border border-white/10">
                  <Heart size={16} className={
                    activeCallReport.sentiment === 'positive' 
                      ? 'text-[#C5A059] fill-[#C5A059]' 
                      : activeCallReport.sentiment === 'negative'
                        ? 'text-red-400 fill-red-400'
                        : 'text-amber-400 fill-amber-400'
                  } />
                  <span className="text-xs font-bold uppercase tracking-wider text-white">
                    {activeCallReport.sentiment === 'positive' ? 'إيجابي وراضٍ' : activeCallReport.sentiment === 'negative' ? 'غاضب ومتذمر' : 'محايد'}
                  </span>
                </div>
              </div>

              {/* Recommendation Coach */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-white/80 flex items-center gap-2">
                  <Sparkles size={16} className="text-[#C5A059]" />
                  <span>توصية مدرب كول كرافت الـ AI:</span>
                </h4>
                <p className="text-xs text-white/70 leading-relaxed bg-[#C5A059]/10 p-4 rounded-2xl border border-[#C5A059]/20 font-sans">
                  {activeCallReport.recommendation}
                </p>
              </div>

            </div>

            <div className="pt-6 border-t border-white/10">
              <div className="text-[10px] font-bold text-[#C5A059] flex items-center gap-2 justify-center">
                <TrendingUp size={14} />
                <span>تعيين أثر التدريب التلقائي</span>
              </div>
            </div>
          </div>
        </motion.div>
      )}

    </div>
  );
};

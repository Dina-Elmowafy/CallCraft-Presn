import React from 'react';
import { motion } from 'motion/react';

interface GlowBackgroundProps {
  currentSlideType?: string;
}

export const GlowBackground: React.FC<GlowBackgroundProps> = ({ currentSlideType }) => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
      {/* Background color of Editorial Aesthetic */}
      <div className="absolute inset-0 bg-[#0A0A0A] transition-colors duration-1000" />

      {/* Grid Pattern with gold/white dot matrix */}
      <div 
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `radial-gradient(#C5A059 1px, transparent 1px)`,
          backgroundSize: '32px 32px'
        }}
      />

      {/* Organic Glowing Blobs in Golden-Oak / Charcoal tones */}
      <div className="absolute inset-0 filter blur-[120px] opacity-30 mix-blend-screen">
        {/* Gold Blob 1 */}
        <motion.div
          animate={{
            x: [0, 30, -30, 0],
            y: [0, -40, 20, 0],
            scale: [1, 1.15, 0.9, 1],
          }}
          transition={{
            duration: 22,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-[-15%] left-[20%] w-[40rem] h-[40rem] rounded-full bg-[#C5A059]/10"
        />

        {/* Warm Bronze/Amber Blob 2 */}
        <motion.div
          animate={{
            x: [0, -40, 40, 0],
            y: [0, 30, -30, 0],
            scale: [1, 0.95, 1.1, 1],
          }}
          transition={{
            duration: 28,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute bottom-[-10%] right-[10%] w-[35rem] h-[35rem] rounded-full bg-[#8F713B]/15"
        />

        {/* Floating Accent Blob */}
        <motion.div
          animate={{
            scale: [1, 1.25, 0.85, 1],
            opacity: [0.2, 0.4, 0.2, 0.2]
          }}
          transition={{
            duration: 18,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-[35%] left-[30%] w-[20rem] h-[20rem] rounded-full bg-[#DBBE83]/10"
        />
      </div>

      {/* Floating elegant speckles */}
      <div className="absolute inset-0 opacity-15">
        <div className="absolute top-1/4 left-1/4 w-[2px] h-[30px] bg-gradient-to-b from-[#C5A059]/40 to-transparent" />
        <div className="absolute top-2/3 right-1/4 w-[30px] h-[2px] bg-gradient-to-r from-transparent to-[#C5A059]/40" />
        <div className="absolute top-1/3 left-2/3 w-1 h-1 bg-[#C5A059] rounded-full animate-pulse [animation-delay:1s]" />
        <div className="absolute top-2/3 left-1/3 w-1.5 h-1.5 bg-[#DBBE83] rounded-full animate-pulse [animation-delay:2s]" />
      </div>

      {/* Decorative vertical editorial line */}
      <div className="absolute top-0 right-12 w-[1px] h-full bg-white/5" />
      <div className="absolute top-0 left-12 w-[1px] h-full bg-white/5" />
    </div>
  );
};
